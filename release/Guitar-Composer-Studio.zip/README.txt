GUITAR COMPOSER STUDIO 0.4.0 - PORTFOLIO EDITION

1. Extract this ZIP completely.
2. Open index.html in Edge, Chrome or another modern desktop browser.
3. Choose Demo complet for an original, locally generated composition.

No ChatGPT account, Ollama, Node.js, terminal or API key is required.
The default composition advisor uses music rules, not an AI language model.
External AI is optional and uses your own provider setup.

Projects are local to this browser. Export .gcsbundle backups to transfer them.
For iPhone, use the published HTTPS website and Add to Home Screen in Safari.
Microphone capture requires browser permission and supported browser APIs.
This browser edition does not provide native ASIO access.
